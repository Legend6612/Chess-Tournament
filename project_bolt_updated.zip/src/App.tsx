import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Phone, ClipboardCheck as ChessBoard, Trophy, Users, MessageCircle } from 'lucide-react';

function App() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-5xl font-bold mb-4 text-blue-400">Chess Masters Tournament</h1>
        <p className="text-xl text-gray-300 mb-8">Advanced chess competitions for professional rewards</p>
        
        {/* Tournament Flyer */}
        <div className="max-w-xl mx-auto bg-white text-gray-900 rounded-2xl overflow-hidden shadow-2xl mb-16">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1529699211952-734e80c4d42b?auto=format&fit=crop&q=80"
              alt="Chess pieces"
              className="w-full h-40 object-cover"
            />
            <div className="absolute top-4 left-4">
              <img 
                src="https://excellentchild.com.ng/logo.png" 
                alt="Excellent Child Logo"
                className="h-10"
              />
            </div>
          </div>
          
          <div className="p-5">
            <h2 className="text-2xl font-bold text-blue-600 mb-4 text-center">CHESS TOURNAMENT 2025</h2>
            
            <div className="space-y-4">
              <div className="text-center bg-blue-50 p-3 rounded-lg">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <span className="text-lg font-semibold">May 27th 2025</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="text-xl font-bold text-blue-600 animate-pulse">
                    {currentTime.toLocaleTimeString()}
                  </span>
                </div>
              </div>

              <div className="flex items-start space-x-2">
                <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                <span className="text-sm">17, Bayo Omotobora Street, Fatai Salami Street, Alogba GRA2, Off N B C Road, Ikorodu, Lagos, Nigeria.</span>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-lg">
                <h3 className="text-lg font-bold text-blue-600 mb-2 text-center">Registration Fee: ₦5,000</h3>
                <ul className="text-sm text-gray-700 space-y-1 list-disc list-inside">
                  <li>Tournament participation</li>
                  <li>Professional game analysis</li>
                  <li>Certificate of participation</li>
                  <li>Refreshments</li>
                </ul>
              </div>
              
              <div className="border-t pt-3 text-center">
                <div className="inline-flex items-center justify-center space-x-2 mb-1">
                  <Phone className="w-5 h-5 text-blue-600" />
                  <span className="text-lg font-semibold">+234 906 042 4363</span>
                </div>
                <div>
                  <a 
                    href="https://excellentchild.com.ng" 
                    className="text-blue-600 hover:text-blue-800 text-sm"
                  >
                    excellentchild.com.ng
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
            <div className="flex justify-center mb-4">
              <ChessBoard className="w-12 h-12 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Advanced Gameplay</h3>
            <p className="text-gray-400">Professional-grade chess matches with live analysis</p>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
            <div className="flex justify-center mb-4">
              <Users className="w-12 h-12 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Connect with Friends</h3>
            <p className="text-gray-400">Challenge friends and join tournaments together</p>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl">
            <div className="flex justify-center mb-4">
              <Trophy className="w-12 h-12 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Competitions</h3>
            <p className="text-gray-400">Regular tournaments with exciting prizes</p>
          </div>
        </div>

        {/* Plans Section */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="bg-gray-800 p-8 rounded-lg shadow-xl">
            <h3 className="text-2xl font-bold mb-4">Community Access</h3>
            <p className="text-gray-400 mb-4">Join our vibrant chess community</p>
            <ul className="text-left mb-8">
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Basic tournament access
              </li>
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Community support
              </li>
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Weekly challenges
              </li>
            </ul>
            <a 
              href="https://chat.whatsapp.com/your-group-link" 
              className="block w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300"
            >
              Join WhatsApp Group
            </a>
          </div>

          <div className="bg-gray-800 p-8 rounded-lg shadow-xl border-2 border-blue-400">
            <h3 className="text-2xl font-bold mb-4">Premium Tournament</h3>
            <p className="text-gray-400 mb-4">For serious chess competitors</p>
            <ul className="text-left mb-8">
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Professional tournament entry
              </li>
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Live game analysis
              </li>
              <li className="flex items-center mb-2">
                <span className="text-green-400 mr-2">✓</span> Private coaching sessions
              </li>
            </ul>
            <button 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300"
              onClick={() => alert('Payment processing...')}
            >
              Click to Pay
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <a 
            href="https://excellentchild.com.ng" 
            className="text-blue-400 hover:text-blue-300 transition duration-300"
          >
            excellentchild.com.ng
          </a>
        </div>
      </footer>
    </div>
  );
}

export default App;